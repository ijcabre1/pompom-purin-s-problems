let currentActivity = 0;
let key1 = false,
  key2 = false,
  key3 = false;
let menuButton, bSound, bColor, bMatching;

function preload() {
  game1Preload();
  game2Preload();
  game3Preload();
  game4Preload();

  pom = loadImage("mainPom.png");
  cld = loadImage("mainCloud.png");
}

function switchToMM() {
  background(150, 200, 245);

  // Hide the home page button, show the activity buttons
  menuButton.hide();
  bSound.show();
  bColor.show();
  bMatching.show();
  bLocked.show();

  if (currentActivity == 1) {
    oneBLion.hide();
    oneBHorse.hide();
    oneBZebra.hide();
    oneBHyena.hide();
    oneBSpeaker.hide();
  }
  if (currentActivity == 2) {
    twoBRetry.hide();
    twoBOrange.hide();
    twoBCyan.hide();
    twoBMagenta.hide();
    twoBRed.hide();
  }
  if (currentActivity == 3) {
    threeBPom.hide();
    threeBSquare.hide();
    threeBCircle.hide();
    threeBTriangle.hide();
    threeBReset.hide();
  }
  if (currentActivity == 4) {
    bAgain.hide();
  }

  currentActivity = 0;

  fill("black");

  textSize(25);
  textFont("Comic Sans MS");
  text("Pom Pom Purins Problem", 50, 75);

  image(pom, -25, 175, 150, 200);
  image(cld, 10, -150, 400, 400);
}

function setup() {
  createCanvas(600, 300);
  background(150, 200, 245);
  menuButton = createButton("Back");
  menuButton.position(0, 0);
  menuButton.mousePressed(switchToMM);
  menuButton.hide();

  bSound = createButton("Sound Recognition");
  bSound.position(375, 100);
  bSound.size(200, 25);
  bSound.mousePressed(game1Setup);
  bSound.show();

  bColor = createButton("Color Recognition");
  bColor.position(375, 150);
  bColor.size(200, 25);
  bColor.mousePressed(game2Setup);
  bColor.show();

  bMatching = createButton("Matching Shapes");
  bMatching.position(375, 200);
  bMatching.size(200, 25);
  bMatching.mousePressed(game3Setup);
  bMatching.show();

  bLocked = createButton("???");
  bLocked.position(200, 250);
  bLocked.size(200, 25);
  bLocked.mousePressed(locked);
  bLocked.show();

  bUnlocked = createButton("PONG");
  bUnlocked.position(200, 250);
  bUnlocked.size(200, 25);
  bUnlocked.mousePressed(game4Setup);
  bUnlocked.hide();
}

function draw() {
  switch (currentActivity) {
    case 0:
      mainMenu();
      break;
    case 1:
      game1Draw();
      break;
    case 2:
      game2Draw();
      break;
    case 3:
      game3Draw();
      break;
    case 4:
      game4Draw();
      break;
  }
}

function mainMenu() {
  textSize(25);
  textFont("Comic Sans MS");
  text("Pom Pom Purins Problem", 50, 75);

  if (key1 == true && key2 == true && key3 == true) {
    bLocked.hide();
    bUnlocked.show();
  }

  image(pom, -25, 175, 150, 200);
  image(cld, 10, -150, 400, 400);
}

function locked() {
  textSize(10);
  text("It's Locked.", 100, 225);
}
