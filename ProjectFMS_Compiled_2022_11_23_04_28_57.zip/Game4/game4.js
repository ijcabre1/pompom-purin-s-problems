hS = 0;
function game4Preload() {}

function game4Setup() {
  createCanvas(600, 300);
  background(150, 200, 245);
  currentActivity = 4;

  // Hide the Activity 4 button, show all the other buttons
  menuButton.show();
  bSound.hide();
  bColor.hide();
  bMatching.hide();
  bLocked.hide();
  bUnlocked.hide();

  angleMode(DEGREES);
  rectMode(CENTER);
  xB = 300;
  yB = 50;
  xBS = 0;
  yBS = 2.5;
  s = 0;

  bAgain = createButton("Play again");
  bAgain.position(265, 125);
  bAgain.hide();
}

function game4Draw() {
  background(150, 200, 245);

  textSize(20);
  text("Score = ", 450, 50);
  text(s, 525, 50);
  text("High Score = ", 450, 20);
  text(hS, 575, 20);
  circle(xB, yB, 15);
  rect(mouseX, 275, 50, 10);
  bAgain.mousePressed(resetGame);
  ballMove();
  paddleBounce();
}

function ballMove() {
  textSize(20);
  xB += xBS;
  yB += yBS;
  if (xB > width || xB < 0) xBS *= -1;
  if (yB < 0) yBS *= -1;
  if (yB > height) gameOver();
}

function paddleBounce() {
  if (xB > mouseX - 25 && xB < mouseX + 25 && yB >= 270 && yB <= 280) {
    xBS = random(-5, 5);
    yBS = yBS * -1 - 0.125;
    s++;
  }
}

function gameOver() {
  text("Game Over", 250, 100);
  bAgain.show();
  if (hS < s) {
    hS = s;
  }
}

function resetGame() {
  xB = 300;
  yB = 50;
  xBS = 0;
  yBS = 2.5;
  s = 0;
  bAgain.hide();
}

/*****
 * Instead of using buttons like other games, this example draws
 * rectangles and circles. The mousePressed function determines if the
 * user clicked on one of the shapes.
 *****/
function game4MousePressed() {}
