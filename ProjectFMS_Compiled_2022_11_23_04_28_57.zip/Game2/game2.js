let twoImg, pomHappy, pomSad;
let x;

var colors = ["MAGENTA", "ORANGE", "RED", "CYAN"];

function game2Preload() {
  twoImg = loadImage("PomPom.png");
  pomHappy = loadImage("PomHappy.png");
  pomSad = loadImage("PomSad.png");
}

function game2Setup() {
  background(150, 200, 245);
  currentActivity = 2;
  key2 = true;

  // Hide the Activity 2 button, show all the other buttons
  menuButton.show();
  bSound.hide();
  bColor.hide();
  bMatching.hide();
  bLocked.hide();
  bUnlocked.hide();
  
  twoAnswer = int(random(1,5));

  twoBCyan = createImg("cyan.png", "cyan");
  twoBCyan.position(180, 65);
  twoBCyan.size(105, 105);

  twoBOrange = createImg("orange.png", "orange");
  twoBOrange.position(290, 65);
  twoBOrange.size(105, 105);

  twoBMagenta = createImg("magenta.png", "magenta");
  twoBMagenta.position(180, 175);
  twoBMagenta.size(105, 105);

  twoBRed = createImg("red.png", "red");
  twoBRed.position(290, 175);
  twoBRed.size(105, 105);

  twoBRetry = createImg("retry.png", "retry");
  twoBRetry.position(540, 10);
  twoBRetry.size(50, 50);
  twoBRetry.mousePressed(Retry);
}

function game2Draw() {
  background(150, 200, 245);

  image(twoImg, 10, 160, 150, 150);

  textFont("Comic Sans MS");
  textSize(20);
  fill(246, 242, 175);
  text("Color Match", 235, 25);

  textSize(30);
  twoRandomAnswer();

  textSize(30);
  text("?", 105, 180);

  textSize(18);
  text("Choose the right color!", 390, 180);
  
  if (twoAnswer == 1) {
   twoBCyan.mousePressed(replyPos); 
  }
  else {
    twoBCyan.mousePressed(replyNeg);
  }
  
  if (twoAnswer == 2) {
   twoBOrange.mousePressed(replyPos); 
  }
  else {
    twoBOrange.mousePressed(replyNeg);
  }
  
  if (twoAnswer == 3) {
   twoBMagenta.mousePressed(replyPos); 
  }
  else {
    twoBMagenta.mousePressed(replyNeg);
  }
  
  if (twoAnswer == 4) {
   twoBRed.mousePressed(replyPos); 
  }
  else {
    twoBRed.mousePressed(replyNeg);
  }

  if (x == 2) {
    image(pomHappy, 150, 70, 320, 225);
    twoBCyan.hide();
    twoBOrange.hide();
    twoBMagenta.hide();
    twoBRed.hide();
  }

  if (x == 1) {
    image(pomSad, 150, 70, 320, 225);
    twoBCyan.hide();
    twoBOrange.hide();
    twoBMagenta.hide();
    twoBRed.hide();
  }
}

function replyPos() {
  background(150, 200, 245);
  fill(246, 242, 175);
  textSize(30);
  x = 2;
}

function replyNeg() {
  let pomSad;
  x = 1;
}
function Retry() {
  background(150, 200, 245);
  
  //expand this later to be random
  textSize(30);
  twoDifferent();
  twoRandomAnswer();
  
  twoBCyan.show();
  twoBOrange.show();
  twoBMagenta.show();
  twoBRed.show();
  x = 0;
}

function twoRandomAnswer() {
    switch(twoAnswer) {
      case 1:
        text("CYAN", 250, 60);
        break;
      case 2:
        text("ORANGE", 225, 60);
        break;
      case 3:
        text("MAGENTA", 210, 60);
        break;
      case 4:
        text("RED", 260, 60);
        break;
    }
  }

function twoDifferent() {
  twoPreviousAnswer = twoAnswer;
  twoTempAnswer = int(random(1,5));
  if (twoPreviousAnswer != twoTempAnswer) {
    twoAnswer = twoTempAnswer;
  }
  else {
    twoDifferent();
  }
}

function game2MousePressed() {}
