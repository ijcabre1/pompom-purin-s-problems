let r, g, b; 
  r = 150
  g = 200
  b = 245

let img;

function game1Preload(){
  img = loadImage("onePom.png");
  spe = loadImage("oneSpeaker.png");
  song = loadSound("oneGrowl.mp3");
}

function game1Setup(){
  currentActivity = 1;
  key1 = true;
  
  // Hide the Game 1 button, show all the other navigation buttons
  menuButton.show();
  bSound.hide();
  bColor.hide();
  bMatching.hide();
  bLocked.hide();
  bUnlocked.hide();
  
  oneBLion = createButton('Lion');
  oneBLion.position(430, 95);
  oneBLion.mousePressed(changeBGG);
  oneBLion.size(100)
  
  oneBHorse = createButton('Horse');
  oneBHorse.position(430, 135);
  oneBHorse.mousePressed(changeBG);
  oneBHorse.size(100)
  
  oneBZebra = createButton('Zebra');
  oneBZebra.position(430, 175);
  oneBZebra.mousePressed(changeBG);
  oneBZebra.size(100)
 
  oneBHyena = createButton('Hyena');
  oneBHyena.position(430, 215);
  oneBHyena.mousePressed(changeBG);
  oneBHyena.size(100)
   
  oneBSpeaker = createImg("oneSpeaker.png", "speaker");
  oneBSpeaker.position(240, 110);
  oneBSpeaker.mousePressed(startPlaying);
  oneBSpeaker.size(140,120)
}

function game1Draw(){
  background (r, g, b )
  image(img, 5, 150, 150, 150);
  textFont('Comic Sans MS')
  fill(246,242,175);
  textSize(25);
  text('Sound Recognition', 200, 40)
  text('Which Animal Is This?', 200, 290)
  text('Lion', 430, 110)
  text('Horse', 430, 150)
  text('Zebra', 430, 190)
  text('Hyena', 430, 230)
}

function startPlaying(){
  if (!song.isPlaying())
    song.play();
    song.setVolume(0.3);
}

function changeBG(){
  r = 200
  g = 0
  b = 0
}

function changeBGG(){
  r = 0
  g = 200
  b = 0
}

function resetSketch(){
  r = 150
  g = 200
  b = 245 
}