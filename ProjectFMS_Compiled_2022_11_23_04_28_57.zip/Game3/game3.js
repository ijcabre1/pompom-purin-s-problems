function game3Preload(){
  
}

function game3Setup(){
  background(150, 200, 245);
  currentActivity = 3;
  key3 = true;
  
  // Hide the Activity 3 button, show all the other buttons
  menuButton.show();
  bSound.hide();
  bColor.hide();
  bMatching.hide();
  bLocked.hide();
  bUnlocked.hide();

  // button pompom
  threeBPom = createImg('200px-Pompompurin.png', "pompom");
  threeBPom.position(0, 75)
  
  //button square
  threeBSquare = createImg('Screenshot_20221102_105859.png', "square")
  threeBSquare.position(475,80);
  
  //button triangle.
  threeBTriangle = createImg('Screenshot_20221102_110508.png', "triangle")
  threeBTriangle.position(475, 220);
  
  //button circle
  threeBCircle = createImg('Screenshot_20221102_110531.png', "circle");
  threeBCircle.position(475, 150);
  
  threeBReset = createButton("Retry");
  threeBReset.position(275, 200);
  threeBReset.mousePressed(reset);
  threeBReset.hide();
  
  threeAnswer = int(random(1,4));
  
  //TEXT 
  textSize(30);
  fill(246, 242, 175);

  textFont('Comic Sans MS')
  //game's name & question
  text('Shape Recognition', 180, 40)
  text('What shape is this?', 170, 280)
  threeRandomAnswer();
}

function replyNo() {
  background(150, 200, 245);
  fill(246, 242, 185);
  let y = 'Try Again!!';
  fill(246, 242, 185);
  text(y, 250, 100, 70, 80);
  threeBReset.show();
}

function replyCorrect() {
  background(150,200,245);
  fill(246, 242, 185);
  let s = 'Congrats!';
  fill(246, 242, 185);
  text(s, 250, 100, 70, 80);
  threeBReset.show();
}

function reset() {
  background(150,200,245);
  text('Shape Recognition', 180, 40);
  text('What shape is this?', 170, 280);
  threeDifferent();
  threeRandomAnswer();
  threeBReset.hide();
}

function threeRandomAnswer() {
    switch(threeAnswer) {
      case 1:
        square(250, 100, 100);
        break;
      case 2:
        circle(300, 150, 100);
        break;
      case 3:
        triangle(300, 100, 350, 200, 250, 200);
        break;
    }
}

function threeDifferent() {
  threePreviousAnswer = threeAnswer;
  threeTempAnswer = int(random(1,4));
  if (threePreviousAnswer != threeTempAnswer) {
    threeAnswer = threeTempAnswer;
  }
  else {
    threeDifferent();
  }
}

function game3Draw(){
  if (threeAnswer == 1) {
    threeBSquare.mousePressed(replyCorrect);
  }
  else {
    threeBSquare.mousePressed(replyNo);
  }
  
  if (threeAnswer == 2) {
    threeBCircle.mousePressed(replyCorrect);
  }
  else {
    threeBCircle.mousePressed(replyNo);
  }
  
  if (threeAnswer == 3) {
    threeBTriangle.mousePressed(replyCorrect);
  }
  else {
    threeBTriangle.mousePressed(replyNo);
  }
}